<div class="main-content">

						<!-- BEGIN .panel -->
						<div class="panel">
							<div class="shortcode-content hreview">
								<div class="article-head">
									<h1 class="fn"><?=$tadbir->title?></h1>
									<!-- <div class="article-info">
										<div class="social-buttons left">
											<a href="#" class="social-thing facebook"><i class="fa fa-facebook"></i><span class="counter">3k</span></a>
											<a href="#" class="social-thing twitter"><i class="fa fa-twitter"></i><span class="counter">1.2k</span></a>
											<a href="#" class="social-thing pinterest"><i class="fa fa-pinterest"></i><span class="counter">620</span></a>
											<a href="#" class="social-thing google"><i class="fa fa-google-plus"></i><span class="counter">200</span></a>
										</div>
										<div class="right">
											<span class="reviewer"><i class="fa fa-user"></i> by Orange-Themes</span>, <span class="dtreviewed"><i class="fa fa-clock-o"></i> 6 Jan. 2014<span class="value-title" title="2014-01-06"></span></span>
										</div>
										<div class="clear-float"></div>
									</div> -->
								</div>

								<div class="paragraph-row">
									<div class="column6">
										<div class="review-photo"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-35.jpg" alt="" /></div>
										<!-- <div class="paragraph-row">
											<div class="column7">
												<h3 class="panel-title">Rating</h3>
												<div class="rating-table">
													<div class="rate-item">
														<div class="right ot-star-rating"><span style="width:60%"><strong>3</strong> out of 5</span></div>
														<strong>Design</strong>
													</div>
													<div class="rate-item">
														<div class="right ot-star-rating"><span style="width:50%"><strong>2.5</strong> out of 5</span></div>
														<strong>Engine</strong>
													</div>
													<div class="rate-item">
														<div class="right ot-star-rating"><span style="width:70%"><strong>3.5</strong> out of 5</span></div>
														<strong>Price</strong>
													</div>
												</div>
											</div>
											<div class="column5">
												<h3 class="panel-title">Total</h3>
												<div class="rating-total"><div class="master-rate rating">4.5</div>
													<div class="ot-star-rating"><span style="width:90%"><strong>4.5</strong> out of 5</span></div>
												</div>
											</div>
											<div class="spacer-1"></div>
										</div> -->
									</div>
									<div class="column6">
										
										<!-- BEGIN .panel -->
										<div class="panel">
											<div class="p-title">
												<h2>Overview</h2>
											</div>
											<ul>
												<!-- <li><strong>Type:</strong> <a href="#">1stGen</a>, <a href="#">E-Readers</a>, <a href="#">GPS</a>, <a href="#">Laptops</a>, <a href="#">Touch</a></li> -->
												<!-- <li><strong>Brand:</strong> <a href="#">Nikon</a>, <a href="#">Canon</a>, <a href="#">Sony</a>, <a href="#">Olympus</a></li>
												<li><strong>Retailer:</strong> <a href="#">Walmart</a>, <a href="#">BestBuy</a>, <a href="#">NewEgg</a></li>
												<li><strong>Release Date:</strong> February 23th, 2013</li>
												<li><strong>Pros:</strong><p>Quo te partem nusquam salutatus, nobis oratio vel ut. Duo te quod salutatus.</p></li>
												<li><strong>Cons:</strong><p>In qui facilisis appellantur, pro vero aliquid fabulas cu. Pri cu facete debitis fabellas, accusam voluptua ad mel.</p></li>
												<li><strong>Conclusion:</strong><p class="summary">Nibh voluptua eleifend sed ne, ex melius maiorum vix, ea case percipit sit. Quo in scripta prodesset, ex nam sonet theophrastus.</p></li> -->
											</ul>
										<!-- END .panel -->
										</div>

									</div>
								</div>

								<p class="description"><?=$tadbir->text?></p>

								<!-- <p>Qui id dicit homero graece. No per vivendo maluisset, ei mel dicat appetere. Sit quando doming officiis at, et has summo essent perpetua. Summo mollis molestiae in mea, iudico periculis inciderint eum cu, has id reque singulis consequat. Accusam blandit duo te. Ius quis nonumy no.</p>

								<p>Utamur atomorum te pri, falli postea per ea. Dicam eleifend no vel, ex mea autem impetus senserit. In meis nobis cotidieque eos. In sumo pertinax tincidunt mel, per id solum ponderum philosophia, ad per brute minimum. Salutatus elaboraret eos ex, his ex saepe discere scribentur, ferri definitiones mel te.</p>

								<p>Ut laoreet maluisset deterruisset his, eros voluptua erroribus in eam. Virtute comprehensam an mel, vis ferri audire te, volumus corrumpit sed ei. Latine deterruisset nec id, eirmod menandri perpetua et mei. Ne mel tation graece. Nam dictas nostrud sanctus et.</p>
								
								<h2>Sed an officiis quaerendum scribentur, dicunt appellantur quo ei</h2>

								<p>Vide clita at his, usu accumsan ponderum te. Usu sapientem mnesarchum et, unum dictas democritum ex mei, eu eam munere albucius. Magna saperet sententiae sed ne. In sea numquam torquatos mediocritatem. Est summo nonumy epicurei ea, equidem ancillae mentitum mel in. Suas accommodare disputationi vim no, duo ne ancillae deleniti theophrastus, et denique democritum voluptatum vis.</p> -->

								<!-- <blockquote class="style-4">
									<p>Perfecto corrumpit no sed, cu facer postea has. In eam iusto dicam, cum ut sale vituperata. Eam dignissim torquatos ne, nobis dolorum sit ut sale vituperata</p>
								</blockquote>

								<p>Qui ex dolores imperdiet sadipscing, nec nibh alienum definitiones te. Id movet malorum voluptatis primis alterum repudiandae ut vel. Ut sea quas fastidii splendide, ne suas denique postulant. Minim vis te minim erant nonumes. Nec oporteat laboramus accommodare an, vix soluta placerat recteque mutat suscipit intellegebat et sed.</p> -->

								<!-- <div class="article-foot">
									<div class="left">
										<span><i class="fa fa-folder-open"></i> Categories:</span><a href="#">jewelry</a>, <a href="#">REVIEWS</a>
									</div>
									<div class="right">
										<span><i class="fa fa-tags"></i> Tags:</span><a href="#">JEWELERY</a>, <a href="#">REVIEWS</a>
									</div>
									<div class="clear-float"></div>
								</div> -->
							</div>
						<!-- END .panel -->
						</div>
						
						<!-- BEGIN .panel -->
						<!-- <div class="panel">
							<div class="p-title">
								<h2>About Author</h2>
							</div>
							<div class="about-author">
								<div class="about-header">
									<a href="#"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/avatar-4.jpg" alt="" /></a>
								</div>
								<div class="about-content">
									<div class="soc-buttons right">
										<a href="#"><i class="fa fa-facebook"></i></a>
										<a href="#"><i class="fa fa-twitter"></i></a>
										<a href="#"><i class="fa fa-youtube"></i></a>
										<a href="#"><i class="fa fa-pinterest"></i></a>
										<a href="#"><i class="fa fa-linkedin"></i></a>
										<a href="http://plus.google.com/114851242423972622339"><i class="fa fa-google-plus" rel="author"></i></a>
									</div>
									<h3><a href="#">Orange-Themes</a></h3>
									<p>Lorem ipsum dolor sit amet, aeque doctus phaedrum qui in, expetenda consequuntur nec te, ut labores pertinax his. Id pri utroque deleniti, sadipscing neglegentur cum ei. Eos audiam definitionem et, mea autem graece alterum ne. Periculis conceptam per et.</p>
								</div>
								<div class="clear-float"></div>
							</div>
						</div> -->
						<!-- END .panel -->
						
						<!-- BEGIN .panel -->
						<!-- <div class="panel">
							<div class="p-title">
								<h2>Related Articles</h2>
							</div>
							<div class="video-carousel">
								<a href="#" class="carousel-left"><i class="fa fa-chevron-left"></i></a>
								<a href="#" class="carousel-right"><i class="fa fa-chevron-right"></i></a> -->
								<!-- BEGIN .inner-carousel -->
								<!-- <div class="inner-carousel">
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-20.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">The all-new BMW i8. Official Launch Video</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-21.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">BMW 335Dx Review</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-22.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">BMW M5 V8 5.0L Review</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-20.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">The all-new BMW i8. Official Launch Video</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-21.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">BMW 335Dx Review</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-20.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">The all-new BMW i8. Official Launch Video</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-21.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">BMW 335Dx Review</a></h3>
									</div>
									<div class="item">
										<a href="post-video.html"><img src="<?=Yii::getAlias('@web')?>/foto/images/photos/image-22.jpg" class="item-photo" alt="" /></a>
										<h3><a href="post-video.htm">BMW M5 V8 5.0L Review</a></h3>
									</div> -->
								<!-- END .inner-carousel -->
								<!-- </div>
							</div>
						</div> -->
						<!-- END .panel -->
						
	
					</div>