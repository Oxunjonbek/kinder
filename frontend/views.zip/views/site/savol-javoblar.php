<div class="main-content">

						<!-- BEGIN .panel -->
						<div class="panel">
							<div class="p-title">
								<h2>Farmonlar</h2>
							</div>
							<div class="blog-list style-1">
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-15.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #648126;"><strong>Electronics</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-49.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #c32929;"><strong>Design</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-50.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #c32929;"><strong>Design</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-16.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #c32929;"><strong>Design</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-15.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #648126;"><strong>Electronics</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-49.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #c32929;"><strong>Design</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>
								
								<div class="item">
									<div class="item-header">
										<a href="post.html"><img src="images/photos/image-50.jpg" alt="" class="item-photo" /></a>
									</div>
									<div class="item-content">
										<a href="blog.html" class="category-link" style="color: #c32929;"><strong>Design</strong></a>
										<h3><a href="post.html">BMW E60 Test Drive from TOP GEAR</a></h3>
										<p>Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready for another seasonal display of wealth, as some of world’s. Sotheby’s in London is getting ready.</p>
									</div>
									<div class="item-footer">
										<span class="right">
											<a href="blog.html"><i class="fa fa-clock-o"></i> 4 Jan, 2014</a>
											<a href="blog.html"><i class="fa fa-comment"></i> 3</a>
										</span>
									</div>
								</div>

							</div>
						<!-- END .panel -->
						</div>

						<!-- BEGIN .panel -->
						<div class="panel">
							<div class="pagination">
								<a href="#" class="prev page-numbers"><i class="fa fa-caret-left"></i></a>
								<a href="#" class="page-numbers">1</a>
								<a href="#" class="page-numbers current">2</a>
								<a href="#" class="page-numbers">3</a>
								<a href="#" class="page-numbers">4</a>
								<a href="#" class="page-numbers">6</a>
								<a href="#" class="next page-numbers"><i class="fa fa-caret-right"></i></a>
							</div>
						<!-- END .panel -->
						</div>

					</div>