                <!-- BEGIN .wrapper -->
                <div class="wrapper" style="background-color: rgb(11, 82, 100);">

                    <!-- BEGIN .breaking-news -->
                    <div class="breaking-news">
                        <!-- <div class="breaking-title">
                            <h3>Breaking News</h3>
                            <i></i>
                        </div>
                        <div class="breaking-block">
                            <ul>
                                <li><h4><a href="post.html">Albucius moderatius contentiones pri in, ei tota brute eam</a></h4><i class="fa fa-exclamation"></i></li>
                                <li><h4><a href="post.html">Albucius moderatius contentiones pri in, ei tota brute eam</a></h4><i class="fa fa-exclamation"></i></li>
                                <li><h4><a href="post.html">Albucius moderatius contentiones pri in, ei tota brute eam</a></h4><i class="fa fa-exclamation"></i></li>
                            </ul>
                        </div> -->
                    <!-- END .breaking-news -->
                    </div>

                <!-- END .wrapper -->
                </div>